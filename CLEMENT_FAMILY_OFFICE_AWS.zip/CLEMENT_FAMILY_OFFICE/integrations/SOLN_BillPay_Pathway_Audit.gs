/** Read-only configuration and ledger audit. Does not call providers or write data.
 * Replace the previous SOLN_billPayPathwayAudit and SOLN_billPayAuditRows_ definitions.
 * Do not install both versions. Receipts are recorded evidence, not verified signatures.
 */
function SOLN_billPayPathwayAudit() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) throw new Error('Open the spreadsheet-bound SOLN project.');
  const findings = [];
  const check = (stage, ok, detail) => findings.push({stage: stage, pass: !!ok, detail: detail});
  const key = value => String(value == null ? '' : value).trim().toLowerCase();
  const expected = {
    SOLN_BillPay_Requests: ['paymentId','vendor','walletId','usdCents','lndCents','status','providerId','providerReceipt'],
    SOLN_Sync_Outbox: ['paymentId','state','providerId','receipt'],
    SOLN_Sync_Inbox: ['eventId','paymentId','providerId','status','receipt'],
    SOLN_Sync_Exceptions: ['paymentId','stage','detail']
  };
  const rows = {};
  Object.keys(expected).forEach(name => {
    const sheet = ss.getSheetByName(name);
    rows[name] = [];
    if (!sheet) { check(name, false, 'Sheet absent'); return; }
    const width = sheet.getLastColumn();
    if (width > 100) { check(name, false, 'More than 100 columns; review schema before scanning'); return; }
    const headers = width ? sheet.getRange(1,1,1,width).getDisplayValues()[0].map(key) : [];
    const missing = expected[name].filter(h => headers.indexOf(key(h)) < 0);
    const duplicates = headers.filter((h,i) => h && headers.indexOf(h) !== i);
    check(name, !missing.length && !duplicates.length,
      missing.length || duplicates.length ? 'Missing: '+missing.join(', ')+'; duplicate normalized headers: '+duplicates.join(', ') : 'Headers present (case-insensitive)');
    if (missing.length || duplicates.length) return;
    const count = Math.max(0, sheet.getLastRow()-1);
    if (count > 10000) { check('SCAN '+name,false,'Over 10,000 rows; no partial payment conclusion produced'); return; }
    rows[name] = SOLN_billPayAuditRows_(sheet);
  });
  const handlers = {
    solnBillPayInbound_: typeof solnBillPayInbound_,
    solnBillPaySubmit: typeof solnBillPaySubmit,
    SOLN_syncDispatch: typeof SOLN_syncDispatch,
    SOLN_syncReceive_: typeof SOLN_syncReceive_,
    SOLN_syncReconcile: typeof SOLN_syncReconcile,
    SOLN_autoInstall: typeof SOLN_autoInstall,
    SOLN_autoPollProvider_: typeof SOLN_autoPollProvider_,
    SOLN_liveProviderSubmit_: typeof SOLN_liveProviderSubmit_
  };
  Object.keys(handlers).forEach(name => check('HANDLER '+name,handlers[name]==='function',handlers[name]));
  try {
    const props = PropertiesService.getScriptProperties();
    const endpoint = String(props.getProperty('SOLN_BILLPAY_PROVIDER_ENDPOINT') || '');
    const statusUrl = String(props.getProperty('SOLN_BILLPAY_PROVIDER_STATUS_URL') || '');
    const token = !!props.getProperty('SOLN_BILLPAY_PROVIDER_TOKEN');
    const name = !!props.getProperty('SOLN_BILLPAY_PROVIDER_NAME');
    check('PROVIDER SUBMIT', /^https:\/\/[^/\s]+\/.+/.test(endpoint) && token && name,
      'HTTPS endpoint configured: '+/^https:\/\/[^/\s]+\/.+/.test(endpoint)+'; provider name: '+name+'; token present: '+token+'; credentials and production environment not tested');
    check('PROVIDER STATUS', /^https:\/\/[^\s]+/.test(statusUrl) && statusUrl.indexOf('{providerId}')>=0 && token,
      'Status template configured: '+!!statusUrl+'; token present: '+token+'; no provider request made');
    const ingress = !!props.getProperty('SOLN_SYNC_INGRESS_SECRET');
    check('INGRESS SECRET PRESENT',ingress,'Secret present: '+ingress+'; verifier implementation not assessed');
    ['SOLN_AUTO_BILLPAY','SOLN_AUTO_STATUS_POLL','SOLN_AUTO_RECONCILE'].forEach(name => {
      const value = String(props.getProperty(name) || 'UNSET');
      check('AUTOMATION '+name,value.toUpperCase()==='YES',value==='UNSET'?'UNSET':value.toUpperCase()==='YES'?'YES':'Not YES');
    });
  } catch (error) { check('PROPERTY ACCESS',false,'Unable to inspect configuration'); }
  try {
    const triggers = ScriptApp.getProjectTriggers().map(t => t.getHandlerFunction());
    ['SOLN_autoFiveMinute','SOLN_autoHourly'].forEach(name => check('TRIGGER '+name,triggers.indexOf(name)>=0,triggers.indexOf(name)>=0?'Visible to executing user':'Not visible; triggers owned by other users may not be listed'));
  } catch (error) { check('TRIGGER ACCESS',false,'Unable to inspect triggers'); }
  const requests = rows.SOLN_BillPay_Requests;
  const outbox = rows.SOLN_Sync_Outbox;
  const inbox = rows.SOLN_Sync_Inbox;
  const payments = [];
  ['GEORGIA POWER','VERIZON','SYNC'].forEach(vendor => {
    const matches = requests.filter(r => String(r.vendor || '').toUpperCase().indexOf(vendor)>=0);
    check('VENDOR '+vendor,matches.length>0,matches.length+' request(s) in inspected rows; no payment inferred');
    matches.forEach(r => {
      const id = String(r.paymentid || '').trim();
      const queued = id ? outbox.filter(x => String(x.paymentid || '').trim()===id) : [];
      const events = id ? inbox.filter(x => String(x.paymentid || '').trim()===id) : [];
      const providerIds = [r.providerid].concat(queued.map(x=>x.providerid)).map(x=>String(x || '').trim()).filter(String);
      const uniqueProviders = providerIds.filter((x,i,a)=>a.indexOf(x)===i);
      const finals = events.filter(x => ['SETTLED','RETURNED','FAILED'].indexOf(String(x.status || '').trim().toUpperCase())>=0 && String(x.receipt || '').trim());
      const matched = finals.filter(x=> uniqueProviders.length===1 && String(x.providerid || '').trim()===uniqueProviders[0]);
      payments.push({vendor:vendor,paymentId:id,requestStatus:String(r.status || ''),
        validPaymentId:!!id,outboxStates:queued.map(x=>String(x.state || '')),providerIdPresent:providerIds.length>0,
        providerIdConflict:uniqueProviders.length>1,recordedFinalStatuses:finals.map(x=>String(x.status)),
        matchedProviderReceiptPresent:matched.length>0,signatureVerification:'NOT_PERFORMED',
        externalSettlementVerified:false});
      check('PAYMENT ID '+vendor,!!id,id?'ID present':'Blank ID; no outbox/inbox match attempted');
    });
  });
  const legacy = ss.getSheetByName('LIVE BILL PAY');
  if (legacy && legacy.getLastRow()>=41) {
    const state = String(legacy.getRange('B41').getDisplayValue()).trim();
    check('LEGACY FORM RESULT',false,state==='LOCAL_BYPASS_VERIFIED'?'Local bypass; external settlement not established':state?'Legacy status present; requires authenticated provider evidence':'No legacy result recorded');
  }
  const result = {checkedAt:new Date().toISOString(),checks:findings,payments:payments,
    productionVerified:false,externalRequestsMade:0,
    note:'Configuration and ledger inspection only. Function presence, flags, receipts and workbook statuses do not establish authenticated external settlement.'};
  console.log(JSON.stringify(result));
  return result;
}
function SOLN_billPayAuditRows_(sheet) {
  if (!sheet || sheet.getLastRow()<2) return [];
  const width=sheet.getLastColumn(), count=sheet.getLastRow()-1;
  if (width>100 || count>10000) throw new Error('Audit scan bound exceeded');
  const headers=sheet.getRange(1,1,1,width).getDisplayValues()[0].map(v=>String(v).trim().toLowerCase());
  if (headers.some((h,i)=>h && headers.indexOf(h)!==i)) throw new Error('Duplicate normalized headers');
  return sheet.getRange(2,1,count,width).getValues().filter(row=>row.some(v=>v!=='' && v!=null)).map(row=>{
    const entry={}; headers.forEach((h,i)=>{if(h)entry[h]=row[i];}); return entry;
  });
}
