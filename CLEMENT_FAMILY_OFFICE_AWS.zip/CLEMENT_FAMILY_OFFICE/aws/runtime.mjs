import {createCipheriv,createDecipheriv,createHash,createPublicKey,randomBytes,timingSafeEqual,verify} from 'node:crypto';
export const MAX_BODY=4*1024*1024;
const enc=x=>Buffer.from(x).toString('base64url');
const security={'cache-control':'no-store','x-content-type-options':'nosniff','referrer-policy':'no-referrer','strict-transport-security':'max-age=31536000; includeSubDomains'};
const response=(status,body,headers={})=>new Response(body,{status,headers:{...security,...headers}});
export function seal(value,key){const iv=randomBytes(12),cipher=createCipheriv('aes-256-gcm',key,iv);const body=Buffer.concat([cipher.update(JSON.stringify(value)),cipher.final()]);return [iv,cipher.getAuthTag(),body].map(enc).join('.');}
export function unseal(value,key){try{const parts=String(value).split('.');if(parts.length!==3)return null;const [iv,tag,body]=parts.map(x=>Buffer.from(x,'base64url'));if(iv.length!==12||tag.length!==16)return null;const decipher=createDecipheriv('aes-256-gcm',key,iv);decipher.setAuthTag(tag);return JSON.parse(Buffer.concat([decipher.update(body),decipher.final()]).toString());}catch{return null;}}
const equal=(a,b)=>typeof a==='string'&&typeof b==='string'&&Buffer.byteLength(a)===Buffer.byteLength(b)&&timingSafeEqual(Buffer.from(a),Buffer.from(b));
export function cookies(event){const out={};for(const line of event.cookies||[]){for(const part of line.split(';')){const pos=part.indexOf('=');if(pos>0)out[part.slice(0,pos).trim()]=part.slice(pos+1).trim();}}return out;}
const cookie=(name,value,age)=>`${name}=${value}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${age}`;
export function verifyIdToken(token,keys,config,nonce){
 if(typeof token!=='string'||token.length>12000)throw Error('Invalid identity');
 const parts=token.split('.');if(parts.length!==3)throw Error('Invalid identity');
 const header=JSON.parse(Buffer.from(parts[0],'base64url')),claims=JSON.parse(Buffer.from(parts[1],'base64url'));
 if(header.alg!=='RS256'||typeof header.kid!=='string')throw Error('Invalid algorithm');
 const jwk=keys.find(k=>k.kid===header.kid&&k.kty==='RSA'&&(!k.use||k.use==='sig'));
 if(!jwk||!verify('RSA-SHA256',Buffer.from(parts[0]+'.'+parts[1]),createPublicKey({key:jwk,format:'jwk'}),Buffer.from(parts[2],'base64url')))throw Error('Invalid signature');
 const now=Math.floor(Date.now()/1000);
 if(claims.iss!==config.issuer||claims.aud!==config.clientId||claims.token_use!=='id'||!Number.isInteger(claims.exp)||claims.exp<=now||!Number.isInteger(claims.iat)||claims.iat>now+60||typeof claims.sub!=='string'||!claims.sub||claims.email_verified!==true||typeof claims.email!=='string'||nonce!==undefined&&!equal(claims.nonce,nonce))throw Error('Invalid claims');
 return claims;
}
export function makeBucket(send,{GetObjectCommand,PutObjectCommand},bucket){
 return {async get(key){
  let obj;try{obj=await send(new GetObjectCommand({Bucket:bucket,Key:key}));}catch(e){if(e.$metadata?.httpStatusCode===404||e.name==='NoSuchKey')return null;throw e;}
  if(obj.ContentLength>MAX_BODY)throw Error('Object requires large-file migration support');
  const body=Buffer.from(await obj.Body.transformToByteArray());let meta={};
  if(obj.Metadata?.['soln-meta'])try{meta=JSON.parse(Buffer.from(obj.Metadata['soln-meta'],'base64url').toString());}catch{throw Error('Object metadata invalid');}
  return {etag:String(obj.ETag).replace(/^"|"$/g,''),body,json:async()=>JSON.parse(body.toString()),text:async()=>body.toString(),httpMetadata:{contentType:obj.ContentType},customMetadata:meta};
 },async put(key,value,opts={}){
  const body=typeof value==='string'?Buffer.from(value):Buffer.from(await new Response(value).arrayBuffer());
  if(body.length>MAX_BODY)throw Error('Object exceeds AWS upload limit');
  const params={Bucket:bucket,Key:key,Body:body,ServerSideEncryption:'AES256',ContentType:opts.httpMetadata?.contentType||'application/octet-stream',Metadata:{'soln-meta':enc(JSON.stringify(opts.customMetadata||{}))}};
  if(opts.onlyIf?.etagMatches)params.IfMatch='"'+opts.onlyIf.etagMatches.replace(/^"|"$/g,'')+'"';
  if(opts.onlyIf?.etagDoesNotMatch)params.IfNoneMatch=opts.onlyIf.etagDoesNotMatch;
  try{const result=await send(new PutObjectCommand(params));return {etag:String(result.ETag).replace(/^"|"$/g,'')};}catch(e){if([409,412].includes(e.$metadata?.httpStatusCode))return null;throw e;}
 }};
}
export async function gatewayResponse(res){
 const bytes=Buffer.from(await res.arrayBuffer());
 if(bytes.length>MAX_BODY)return {statusCode:413,headers:security,body:'Response exceeds AWS delivery limit'};
 const headers=Object.fromEntries([...res.headers].filter(([k])=>k!=='set-cookie'));
 const cookies=res.headers.getSetCookie?.()||[];
 return {statusCode:res.status,headers:{...security,...headers},cookies,body:bytes.toString('base64'),isBase64Encoded:true};
}
export function createHandler({app,config,bucket,getKey,getJwks,fetchImpl=fetch}){
 return async event=>{
  try{
   const method=event.requestContext?.http?.method||'';
   const host=new URL(config.origin).host;
   if(event.requestContext?.domainName!==host)return gatewayResponse(response(400,'Invalid host'));
   const path=event.rawPath||'/',query=event.rawQueryString||'',url=new URL(path+(query?'?'+query:''),config.origin);
   const raw=event.body?Buffer.from(event.body,event.isBase64Encoded?'base64':'utf8'):Buffer.alloc(0);
   if(raw.length>MAX_BODY)return gatewayResponse(response(413,'Uploads are limited to 4 MiB on this AWS deployment.'));
   if(path==='/health'&&method==='GET')return gatewayResponse(response(200,JSON.stringify({service:'Clement Family Office AWS',status:'serving',ledgerConnected:false,paymentExecution:false}),{'content-type':'application/json'}));
   const key=await getKey(),jar=cookies(event);
   if(path==='/auth/login'&&method==='GET'){
    const flow={state:enc(randomBytes(32)),nonce:enc(randomBytes(32)),verifier:enc(randomBytes(48)),created:Date.now()};
    const target=new URL(config.authOrigin+'/oauth2/authorize');
    for(const [k,v] of Object.entries({client_id:config.clientId,response_type:'code',redirect_uri:config.origin+'/auth/callback',scope:'openid email profile',state:flow.state,nonce:flow.nonce,code_challenge:enc(createHash('sha256').update(flow.verifier).digest()),code_challenge_method:'S256'}))target.searchParams.set(k,v);
    const res=response(302,'',{location:target.href});res.headers.append('set-cookie',cookie('__Host-clement-flow',seal(flow,key),600));return gatewayResponse(res);
   }
   if(path==='/auth/callback'&&method==='GET'){
    const flow=unseal(jar['__Host-clement-flow'],key);
    if(!flow||!Number.isFinite(flow.created)||Date.now()-flow.created>600000||Date.now()<flow.created||!equal(flow.state,url.searchParams.get('state'))||!url.searchParams.get('code'))return gatewayResponse(response(400,'Sign-in expired or rejected. Start again at /auth/login.'));
    const exchange=await fetchImpl(config.authOrigin+'/oauth2/token',{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'authorization_code',client_id:config.clientId,code:url.searchParams.get('code'),redirect_uri:config.origin+'/auth/callback',code_verifier:flow.verifier}),redirect:'error',signal:AbortSignal.timeout(15000)});
    if(!exchange.ok)throw Error('Sign-in exchange rejected');
    const result=await exchange.json();verifyIdToken(result.id_token,await getJwks(),config,flow.nonce);
    const res=response(302,'',{location:config.origin+'/'});res.headers.append('set-cookie',cookie('__Host-clement-session',seal({idToken:result.id_token},key),3600));res.headers.append('set-cookie',cookie('__Host-clement-flow','',0));return gatewayResponse(res);
   }
   if(path==='/auth/logout'&&method==='POST'){
    if(event.headers?.origin!==config.origin)return gatewayResponse(response(403,'Origin rejected'));
    const target=new URL(config.authOrigin+'/logout');target.searchParams.set('client_id',config.clientId);target.searchParams.set('logout_uri',config.origin+'/auth/logged-out');
    const res=response(200,JSON.stringify({logoutUrl:target.href}),{'content-type':'application/json'});res.headers.append('set-cookie',cookie('__Host-clement-session','',0));return gatewayResponse(res);
   }
   if(path==='/auth/logged-out'&&method==='GET')return gatewayResponse(response(200,'Signed out. Visit /auth/login to sign in.'));
   const session=unseal(jar['__Host-clement-session'],key);let identity;
   if(session)try{identity=verifyIdToken(session.idToken,await getJwks(),config);}catch{}
   if(!identity){
    if(path==='/'&&method==='GET')return gatewayResponse(response(200,'<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Clement Family Office</title><body style="font:18px system-ui;max-width:600px;margin:12vh auto;padding:24px"><h1>Clement Family Office</h1><p>Private family workspace</p><a href="/auth/login">Sign in securely</a></body></html>',{'content-type':'text/html; charset=utf-8','content-security-policy':"default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; frame-ancestors 'none'"}));
    return gatewayResponse(response(401,JSON.stringify({error:'Sign in at /auth/login'}),{'content-type':'application/json'}));
   }
   // Discard caller-supplied identity, host and proxy headers. Only verified Cognito claims reach the app.
   const headers=new Headers();
   for(const [name,value] of Object.entries(event.headers||{}))if(!/^(oai-|x-oai-|x-forwarded-|host$|authorization$|cookie$|content-length$)/i.test(name))headers.set(name,value);
   headers.set('oai-authenticated-user-id','cognito:'+identity.sub);
   headers.set('oai-authenticated-user-email',identity.email.toLowerCase());
   const request=new Request(url,{method,headers,...(!['GET','HEAD'].includes(method)?{body:raw}:{} )});
   let res=await app.fetch(request,{BUCKET:bucket,PAYMENT_CONFIG_KEY:createHash('sha256').update(key).update('plaid-config').digest('hex')});
   if(path==='/'&&res.headers.get('content-type')?.startsWith('text/html')){
    let html=await res.text();
    html=html.replace('Owner-private workspace','AWS authenticated workspace');
    html+='<div style="position:fixed;right:16px;bottom:16px;z-index:9999"><button onclick="fetch(\'/auth/logout\',{method:\'POST\'}).then(r=>r.json()).then(r=>location.href=r.logoutUrl)">Sign out</button></div>';
    res=new Response(html,{status:res.status,headers:res.headers});
   }
   return gatewayResponse(res);
  }catch{return gatewayResponse(response(503,JSON.stringify({error:'Private workspace unavailable. Retry or inspect AWS logs without logging credentials.'}),{'content-type':'application/json'}));}
 };
}
