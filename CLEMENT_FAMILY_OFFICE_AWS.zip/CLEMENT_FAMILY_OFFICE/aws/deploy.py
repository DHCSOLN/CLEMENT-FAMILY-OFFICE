#!/usr/bin/env python3
"""Publish this source to the owner's private GitHub repo and deploy on AWS.
Run in AWS CloudShell. No private records, uploads, tokens or certificates are
uploaded to GitHub. No ledger transaction or external payment is initiated.
"""
import argparse,base64,getpass,hashlib,io,json,os,secrets,subprocess,sys,time,urllib.request,urllib.error,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
ACCOUNT='944870884457';REGION='us-east-2';STACK='clement-family-office'
REPO='DHCSOLN/CLEMENT-FAMILY-OFFICE';BRANCH='deployment/aws-family-office'
OWNER='dynastyhealing1111@gmail.com';PRIVATE=[]
def github(token,path,method='GET',data=None):
 req=urllib.request.Request('https://api.github.com/repos/'+REPO+path,method=method,headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','User-Agent':'Clement-Family-Office-Installer','Content-Type':'application/json'},data=None if data is None else json.dumps(data).encode())
 try:
  with urllib.request.urlopen(req,timeout=30) as r:return json.load(r)
 except urllib.error.HTTPError as e:raise RuntimeError('GitHub HTTP '+str(e.code)+' for '+path+'. Check repository access/contents-write permission.') from None

def source_files():
 # Explicit tracked source layout: no deployment state, private records or auth files.
 allowed=[]
 for item in ['package.json','README.md','PLAID_SETUP.md','AWS_DEPLOYMENT.md','.gitignore','.openai/hosting.json']:
  p=ROOT/item
  if p.is_file():allowed.append(p)
 for folder in ['src','worker','scripts','integrations','aws']:
  for p in sorted((ROOT/folder).rglob('*')):
   if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ['.pyc','.pem','.key','.p12','.pfx'] and not p.name.startswith('.env'):
    allowed.append(p)
 return allowed

def push_github(token):
 repo=github(token,'')
 if not repo.get('private'):raise RuntimeError('Family Office source is private. Refusing to upload to a public repository.')
 if not repo.get('permissions',{}).get('push'):raise RuntimeError('GitHub token does not have repository push permission.')
 default=repo.get('default_branch','main')
 if repo.get('size',0)==0:
  try:github(token,'/git/ref/heads/'+default)
  except RuntimeError as e:
   if 'HTTP 404' not in str(e) and 'HTTP 409' not in str(e):raise
   github(token,'/contents/README.md','PUT',{'message':'Initialize private Clement Family Office repository','content':base64.b64encode(b'# Clement Family Office\nPrivate application source. See family-office/AWS_DEPLOYMENT.md.\n').decode()})
 default_head=github(token,'/git/ref/heads/'+default)['object']['sha']
 try:head=github(token,'/git/ref/heads/'+BRANCH)['object']['sha'];exists=True
 except RuntimeError as e:
  if 'HTTP 404' not in str(e):raise
  head=default_head;exists=False
 commit=github(token,'/git/commits/'+head)
 entries=[]
 for p in source_files():
  raw=p.read_bytes()
  if len(raw)>2_000_000:raise RuntimeError('Unexpected large source file; upload refused.')
  entries.append({'path':'family-office/'+p.relative_to(ROOT).as_posix(),'mode':'100644','type':'blob','content':raw.decode('utf8')})
 tree=github(token,'/git/trees','POST',{'base_tree':commit['tree']['sha'],'tree':entries})
 if tree['sha']==commit['tree']['sha']:
  if not exists:github(token,'/git/refs','POST',{'ref':'refs/heads/'+BRANCH,'sha':head})
 else:
  new=github(token,'/git/commits','POST',{'message':'Deploy Clement Family Office source and private AWS hosting','tree':tree['sha'],'parents':[head]})
  if exists:github(token,'/git/refs/heads/'+BRANCH,'PATCH',{'sha':new['sha'],'force':False})
  else:github(token,'/git/refs','POST',{'ref':'refs/heads/'+BRANCH,'sha':new['sha']})
  head=new['sha']
 print('VERIFIED GITHUB SOURCE: https://github.com/'+REPO+'/tree/'+BRANCH+'/family-office')
 print('GitHub commit: '+head)

def wait(cf):
 for i in range(240):
  s=cf.describe_stacks(StackName=STACK)['Stacks'][0]['StackStatus']
  if s in ['CREATE_COMPLETE','UPDATE_COMPLETE']:return
  if not s.endswith('_IN_PROGRESS'):raise RuntimeError('AWS stack stopped at '+s+'. Inspect CloudFormation events; no data deletion attempted.')
  print('AWS deployment: '+s,flush=True);time.sleep(10)
 raise RuntimeError('AWS is still deploying. Inspect the existing stack before retrying.')

def deploy_aws(session,password):
 s3=session.client('s3');cf=session.client('cloudformation')
 bucket='clement-office-code-'+ACCOUNT+'-'+REGION
 try:s3.head_bucket(Bucket=bucket,ExpectedBucketOwner=ACCOUNT)
 except Exception as e:
  if str(getattr(e,'response',{}).get('Error',{}).get('Code')) not in ['404','NoSuchBucket','NotFound']:raise
  s3.create_bucket(Bucket=bucket,CreateBucketConfiguration={'LocationConstraint':REGION})
 s3.put_public_access_block(Bucket=bucket,PublicAccessBlockConfiguration={'BlockPublicAcls':True,'IgnorePublicAcls':True,'BlockPublicPolicy':True,'RestrictPublicBuckets':True})
 s3.put_bucket_encryption(Bucket=bucket,ServerSideEncryptionConfiguration={'Rules':[{'ApplyServerSideEncryptionByDefault':{'SSEAlgorithm':'AES256'}}]})
 s3.put_bucket_versioning(Bucket=bucket,VersioningConfiguration={'Status':'Enabled'})
 s3.put_bucket_policy(Bucket=bucket,Policy=json.dumps({'Version':'2012-10-17','Statement':[{'Effect':'Deny','Principal':'*','Action':'s3:*','Resource':['arn:aws:s3:::'+bucket,'arn:aws:s3:::'+bucket+'/*'],'Condition':{'Bool':{'aws:SecureTransport':'false'}}}]}))
 payload=io.BytesIO()
 with zipfile.ZipFile(payload,'w',zipfile.ZIP_DEFLATED) as z:
  for name in ['worker/index.js','package.json','aws/index.mjs','aws/runtime.mjs']:z.write(ROOT/name,name)
 raw=payload.getvalue();key='releases/'+hashlib.sha256(raw).hexdigest()+'.zip'
 s3.put_object(Bucket=bucket,Key=key,Body=raw,ServerSideEncryption='AES256')
 template=(ROOT/'aws/template.json').read_text();cf.validate_template(TemplateBody=template)
 params=[{'ParameterKey':'CodeBucket','ParameterValue':bucket},{'ParameterKey':'CodeKey','ParameterValue':key}]
 try:cf.describe_stacks(StackName=STACK);exists=True
 except Exception as e:
  if 'does not exist' not in str(e):raise
  exists=False
 try:
  if exists:cf.update_stack(StackName=STACK,TemplateBody=template,Parameters=params,Capabilities=['CAPABILITY_IAM'])
  else:cf.create_stack(StackName=STACK,TemplateBody=template,Parameters=params,Capabilities=['CAPABILITY_IAM'])
 except Exception as e:
  if 'No updates are to be performed' not in str(e):raise
 wait(cf)
 outputs={o['OutputKey']:o['OutputValue'] for o in cf.describe_stacks(StackName=STACK)['Stacks'][0]['Outputs']}
 cognito=session.client('cognito-idp')
 try:
  existing=cognito.admin_get_user(UserPoolId=outputs['UserPoolId'],Username=OWNER)
  new_user=existing.get('UserStatus')=='FORCE_CHANGE_PASSWORD'
 except cognito.exceptions.UserNotFoundException:
  cognito.admin_create_user(UserPoolId=outputs['UserPoolId'],Username=OWNER,UserAttributes=[{'Name':'email','Value':OWNER},{'Name':'email_verified','Value':'true'}],MessageAction='SUPPRESS');new_user=True
 if new_user:
  cognito.admin_set_user_password(UserPoolId=outputs['UserPoolId'],Username=OWNER,Password=password,Permanent=True)
 print('Owner sign-in account: '+OWNER+'. MFA setup is required on first sign-in.')
 with urllib.request.urlopen(outputs['HealthURL'],timeout=30) as r:health=json.load(r)
 if health.get('service')!='Clement Family Office AWS' or health.get('status')!='serving':raise RuntimeError('AWS health verification did not match the application.')
 with urllib.request.urlopen(outputs['AppURL']+'/api/state',timeout=30) as r:raise RuntimeError('Private state unexpectedly accessible without sign-in.')


def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--aws-only',action='store_true',help='Deploy AWS without claiming GitHub source is uploaded.');p.add_argument('--github-only',action='store_true');a=p.parse_args()
 if a.aws_only and a.github_only:raise RuntimeError('Choose one mode.')
 import boto3
 session=boto3.Session(region_name=REGION)
 if not a.github_only and session.client('sts').get_caller_identity()['Account']!=ACCOUNT:raise RuntimeError('Wrong AWS account. No deployment made.')
 for cmd in [['node','scripts/test-office.mjs'],['node','scripts/test-plaid.mjs'],['node','scripts/test-bill-pay-audit.mjs'],['node','aws/test-runtime.mjs'],['python3','aws/test-template.py']]:subprocess.run(cmd,cwd=ROOT,check=True)
 if not a.aws_only:
  token=getpass.getpass('GitHub token for private DHCSOLN/CLEMENT-FAMILY-OFFICE, contents read/write (hidden): ').strip();PRIVATE.append(token)
  if not token:raise RuntimeError('GitHub authorization missing. No GitHub or AWS deployment made.')
  push_github(token)
 if a.github_only:return
 password=getpass.getpass('Set initial AWS Family Office password (14+ characters; hidden; used only if owner is new): ');PRIVATE.append(password)
 if len(password)<14 or not all([any(c.islower() for c in password),any(c.isupper() for c in password),any(c.isdigit() for c in password),any(not c.isalnum() for c in password)]):raise RuntimeError('Password must have 14+ characters, uppercase, lowercase, digit and symbol.')
 try:deploy_aws(session,password)
 except urllib.error.HTTPError as e:
  if e.code!=401 or not e.url.endswith('/api/state'):raise
  cf=session.client('cloudformation');outputs={o['OutputKey']:o['OutputValue'] for o in cf.describe_stacks(StackName=STACK)['Stacks'][0]['Outputs']}
  print('VERIFIED: AWS app health passed and private data returned 401 without sign-in.')
  print('AWS Family Office: '+outputs['AppURL']);print('Sign in: '+outputs['LoginURL'])
  print('Existing Sites records/uploads have not been migrated. Google ledger and external payments are not connected by this deployment.')

if __name__=='__main__':
 try:main()
 except KeyboardInterrupt:print('\nStopped. Check existing deployment status before retrying.');sys.exit(2)
 except Exception as e:
  message=str(e)
  for value in PRIVATE:
   if value:message=message.replace(value,'[REDACTED]')
  print('BLOCKED: '+message[:1200]);sys.exit(2)
