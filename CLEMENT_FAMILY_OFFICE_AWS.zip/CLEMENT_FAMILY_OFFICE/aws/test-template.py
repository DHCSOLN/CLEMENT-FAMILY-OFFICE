import json,unittest
from pathlib import Path
class TemplateTests(unittest.TestCase):
 def setUp(self):self.t=json.loads(Path(__file__).with_name('template.json').read_text());self.r=self.t['Resources']
 def test_private_storage_and_retention(self):
  b=self.r['PrivateBucket'];self.assertEqual(b['DeletionPolicy'],'Retain');self.assertTrue(all(b['Properties']['PublicAccessBlockConfiguration'].values()));self.assertEqual(b['Properties']['VersioningConfiguration']['Status'],'Enabled')
 def test_auth_settings(self):
  p=self.r['UserPool']['Properties'];self.assertEqual(p['MfaConfiguration'],'ON');self.assertTrue(p['AdminCreateUserConfig']['AllowAdminCreateUserOnly'])
  c=self.r['UserPoolClient']['Properties'];self.assertEqual(c['AllowedOAuthFlows'],['code']);self.assertFalse(c['GenerateSecret'])
 def test_role_scope_and_missing_key_visibility(self):
  statements=self.r['Role']['Properties']['Policies'][0]['PolicyDocument']['Statement']
  self.assertTrue(any(s['Action']==['s3:ListBucket'] and s['Resource']=={'Fn::GetAtt':['PrivateBucket','Arn']} for s in statements))
  for s in statements:self.assertNotEqual(s.get('Resource'),'*')
 def test_dependency_graph_is_acyclic(self):
  graph={name:set() for name in self.r}
  def refs(value):
   if isinstance(value,list):return set().union(*(refs(v) for v in value)) if value else set()
   if not isinstance(value,dict):return set()
   import re
   result=set()
   if 'Ref' in value:result.add(value['Ref'])
   if 'Fn::GetAtt' in value:result.add(value['Fn::GetAtt'][0])
   if 'Fn::Sub' in value and isinstance(value['Fn::Sub'],str):result.update(x.split('.')[0] for x in re.findall(r'\$\{([^}]+)\}',value['Fn::Sub']))
   for v in value.values():result.update(refs(v))
   return result
  for name,r in self.r.items():
   graph[name]=refs(r)&self.r.keys();depends=r.get('DependsOn',[]);graph[name].update([depends] if isinstance(depends,str) else depends)
  done=set()
  def visit(name,stack):
   self.assertNotIn(name,stack,'CloudFormation dependency cycle')
   if name in done:return
   for target in graph[name]:visit(target,stack|{name})
   done.add(name)
  for name in graph:visit(name,set())
if __name__=='__main__':unittest.main()
