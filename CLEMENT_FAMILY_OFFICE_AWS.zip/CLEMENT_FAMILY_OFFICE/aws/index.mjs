import {createHash} from 'node:crypto';
import {S3Client,GetObjectCommand,PutObjectCommand} from '@aws-sdk/client-s3';
import {SecretsManagerClient,GetSecretValueCommand} from '@aws-sdk/client-secrets-manager';
import app from '../worker/index.js';
import {createHandler,makeBucket} from './runtime.mjs';
const s3=new S3Client({}),sm=new SecretsManagerClient({});let keyCache,jwkCache;
const config={origin:process.env.PUBLIC_ORIGIN,clientId:process.env.COGNITO_CLIENT_ID,issuer:process.env.COGNITO_ISSUER,authOrigin:process.env.COGNITO_AUTH_ORIGIN};
const bucket=makeBucket(command=>{
 // Preserve write preconditions even if the runtime-bundled SDK model is older.
 if(command instanceof PutObjectCommand)command.middlewareStack.add(next=>async args=>{
  if(command.input.IfMatch)args.request.headers['if-match']=command.input.IfMatch;
  if(command.input.IfNoneMatch)args.request.headers['if-none-match']=command.input.IfNoneMatch;
  return next(args);
 },{step:'build',name:'familyOfficeWritePreconditions'});
 return s3.send(command);
},{GetObjectCommand,PutObjectCommand},process.env.PRIVATE_BUCKET);
async function getKey(){if(!keyCache){const result=await sm.send(new GetSecretValueCommand({SecretId:process.env.AUTH_SECRET_ARN}));keyCache=createHash('sha256').update(result.SecretString).digest();}return keyCache;}
async function getJwks(){if(!jwkCache||Date.now()-jwkCache.at>300000){const result=await fetch(config.issuer+'/.well-known/jwks.json',{redirect:'error',signal:AbortSignal.timeout(10000)});if(!result.ok)throw Error('Identity keys unavailable');jwkCache={at:Date.now(),keys:(await result.json()).keys};}return jwkCache.keys;}
export const handler=createHandler({app,config,bucket,getKey,getJwks});
