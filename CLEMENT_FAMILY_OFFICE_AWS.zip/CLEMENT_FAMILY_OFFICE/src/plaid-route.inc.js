if(u.pathname==='/api/plaid'){
 if(!read.includes('finance'))return json({error:'Finance access required'},403);
 const configPath=prefix+'plaid/config.json',configObject=await env.BUCKET.get(configPath);let config=configObject?await openSecret(await configObject.json(),configPath,env):null;
 const statePath=prefix+'plaid/banks.json',getBanks=async()=>{const o=await env.BUCKET.get(statePath);return {o,state:o?await o.json():{items:[],history:[]}}};
 const updateBanks=async fn=>{for(let i=0;i<5;i++){const {o,state}=await getBanks();fn(state);state.history=state.history.slice(0,100);const saved=await env.BUCKET.put(statePath,JSON.stringify(state),{onlyIf:o?{etagMatches:o.etag}:{etagDoesNotMatch:'*'},httpMetadata:{contentType:'application/json'}});if(saved)return state}throw Error('Concurrent bank update; reload and try again')};
 const publicConfig=()=>({configured:!!config,encryptionReady:/^[a-f0-9]{64}$/.test(env.PAYMENT_CONFIG_KEY||''),environment:config?.environment||null,clientIdHint:config?'…'+config.clientId.slice(-6):'',updatedAt:config?.updatedAt||null,redirectUri:u.origin+'/',configEtag:configObject?.etag||'new',serverStatus:'Hosted private backend',linkingEnabled:!!config,executionEnabled:false,transferStatus:'Plaid Transfer is not activated; bank linking alone does not pay bills or convert LND'});
 if(request.method==='GET'){const {state}=await getBanks();return json({...publicConfig(),items:state.items,history:state.history})}
 if(!owner||request.method!=='POST'||request.headers.get('origin')!==u.origin)return json({error:'Owner bank administration required'},403);
 const raw=await request.text();if(raw.length>15000)return json({error:'Bank request limit'},413);let b;try{b=JSON.parse(raw)}catch{return json({error:'Invalid JSON'},400)};
 if(b.action==='configure'){
  if(request.headers.get('if-match')!==(configObject?.etag||'new'))return json({error:'Plaid configuration changed; reload'},409);
  if(!PLAID_HOSTS[b.environment]||typeof b.clientId!=='string'||!/^[a-zA-Z0-9_-]{10,100}$/.test(b.clientId)||typeof b.secret!=='string'||b.secret.length>500)return json({error:'Valid Plaid environment, Client ID and secret required'},400);
  const sameClient=config&&b.clientId===config.clientId&&b.environment===config.environment;
  const {state}=await getBanks();if(!sameClient&&state.items.some(x=>x.status!=='Disconnected'))return json({error:'Disconnect existing bank Items before changing the Plaid client or environment'},409);
  const secret=b.secret||sameClient&&config.secret;if(typeof secret!=='string'||secret.length<16)return json({error:'Enter the Plaid secret for this client and environment'},400);
  const next={id:sameClient?config.id:crypto.randomUUID(),clientId:b.clientId,secret,environment:b.environment,updatedAt:new Date().toISOString(),actor:uid};const sealed=await sealSecret(next,configPath,env);
  const saved=await env.BUCKET.put(configPath,JSON.stringify(sealed),{onlyIf:configObject?{etagMatches:configObject.etag}:{etagDoesNotMatch:'*'}});if(!saved)return json({error:'Concurrent Plaid configuration update'},409);
  await updateBanks(state=>state.history.unshift({time:next.updatedAt,action:'Plaid configuration saved; bank linking not yet completed',actor:uid,environment:next.environment}));return json({saved:true,executionEnabled:false});
 }
 if(!config)return json({error:'Configure your Plaid developer Client ID and environment secret first'},503);
 if(b.action==='link'){
  if(b.consent!==true)return json({error:'Confirm authority and consent to link the selected bank account'},400);
  const nonce=crypto.randomUUID(),sessionPath=prefix+'plaid/sessions/'+nonce,now=Date.now();
  const clientUserId=[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(hid+'|'+uid)))].map(x=>x.toString(16).padStart(2,'0')).join('');
  const result=await plaidCall(config,'/link/token/create',{user:{client_user_id:clientUserId},client_name:'Clement Family Office',products:['auth'],country_codes:['US'],language:'en',redirect_uri:u.origin+'/'});
  if(typeof result.link_token!=='string')return json({error:'Plaid Link token missing'},502);
  await env.BUCKET.put(sessionPath,JSON.stringify({actor:uid,household:hid,configId:config.id,created:now,expires:now+1800000,state:'open'}));
  return json({linkToken:result.link_token,linkSession:nonce,environment:config.environment,household:hid});
 }
 if(b.action==='exchange'){
  if(typeof b.publicToken!=='string'||b.publicToken.length>4096||!b.publicToken.startsWith('public-')||typeof b.linkSession!=='string'||!/^[a-f0-9-]{36}$/.test(b.linkSession))return json({error:'Invalid Plaid linking response'},400);
  const sessionPath=prefix+'plaid/sessions/'+b.linkSession,sessionObject=await env.BUCKET.get(sessionPath),session=sessionObject?await sessionObject.json():null;
  if(!session||session.actor!==uid||session.household!==hid||session.configId!==config.id||session.expires<Date.now()||session.state!=='open')return json({error:'Plaid linking session expired, already used or belongs to another workspace'},409);
  const claim=await env.BUCKET.put(sessionPath,JSON.stringify({...session,state:'exchange-started'}),{onlyIf:{etagMatches:sessionObject.etag}});if(!claim)return json({error:'Plaid linking session already processing'},409);
  const exchange=await plaidCall(config,'/item/public_token/exchange',{public_token:b.publicToken});if(typeof exchange.access_token!=='string'||typeof exchange.item_id!=='string')return json({error:'Plaid Item exchange response invalid'},502);
  const itemHash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(exchange.item_id)))].map(x=>x.toString(16).padStart(2,'0')).join(''),itemRef=crypto.randomUUID(),secretPath=prefix+'plaid/items/'+itemRef;
  await env.BUCKET.put(secretPath,JSON.stringify(await sealSecret({accessToken:exchange.access_token,itemId:exchange.item_id,configId:config.id},secretPath,env)));
  const createdAt=new Date().toISOString();await updateBanks(state=>{if(state.items.some(x=>x.itemHash===itemHash&&x.status!=='Disconnected'))throw Error('This bank Item is already linked');state.items.unshift({id:itemRef,itemHash,configId:config.id,environment:config.environment,createdAt,linkedBy:uid,status:'Linked — account refresh pending',accounts:[]});state.history.unshift({time:createdAt,action:'Plaid bank Item linked; no funds moved',actor:uid})});
  // Retain the encrypted Item before account retrieval, so a temporary retrieval failure is recoverable.
  let refreshError=false;try{const data=await plaidCall(config,'/accounts/get',{access_token:exchange.access_token});const accounts=publicBankAccounts(data);await updateBanks(state=>{const item=state.items.find(x=>x.id===itemRef);if(item&&item.status!=='Disconnected')Object.assign(item,{accounts,status:'Linked',refreshedAt:new Date().toISOString()})})}catch{refreshError=true}
  await env.BUCKET.put(sessionPath,JSON.stringify({...session,state:'completed',itemRef}));return json({linked:true,itemRef,refreshPending:refreshError,executionEnabled:false});
 }
 if(b.action==='refresh'||b.action==='disconnect'){
  const {state}=await getBanks(),item=state.items.find(x=>x.id===b.itemRef&&x.status!=='Disconnected');if(!item)return json({error:'Bank Item not found'},404);if(item.configId!==config.id)return json({error:'Bank Item belongs to a different Plaid configuration'},409);
  const secretPath=prefix+'plaid/items/'+item.id,secretObject=await env.BUCKET.get(secretPath);if(!secretObject)return json({error:'Encrypted bank token unavailable'},503);const token=await openSecret(await secretObject.json(),secretPath,env);if(token.configId!==config.id)return json({error:'Plaid credential context mismatch'},409);
  if(b.action==='disconnect'){
   await plaidCall(config,'/item/remove',{access_token:token.accessToken});await updateBanks(state=>{const x=state.items.find(x=>x.id===item.id);if(x){x.status='Disconnected';x.accounts=[];x.disconnectedAt=new Date().toISOString()}state.history.unshift({time:new Date().toISOString(),action:'Plaid bank data connection removed; bank account not closed',actor:uid})});await env.BUCKET.delete(secretPath);return json({disconnected:true});
  }
  const data=await plaidCall(config,'/accounts/get',{access_token:token.accessToken}),accounts=publicBankAccounts(data);await updateBanks(state=>{const x=state.items.find(x=>x.id===item.id);if(x&&x.status!=='Disconnected')Object.assign(x,{accounts,status:'Linked',refreshedAt:new Date().toISOString()})});return json({refreshed:true});
 }
 return json({error:'Unsupported Plaid operation'},400);
}
