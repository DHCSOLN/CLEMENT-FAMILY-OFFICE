# Plaid bank connections

Open **Bank connections** in the existing private Clement Family Office. Select **Set up Plaid**, enter your Plaid developer Client ID and the secret for the selected environment, and save. Use Sandbox for test accounts. Production requires the applicable Plaid product access and approval. Never put secrets in GitHub, chat or ordinary documents.

In the Plaid Dashboard, enable Auth and allow the exact HTTPS redirect URI shown in the app. Select **Link a bank account**, confirm account authority and consent, then complete Plaid Link and any bank authentication. The owner performs linking. People with finance read permission can see the masked account snapshots only in their assigned family workspace. The site remains owner-private until access is separately granted.

Credentials and access tokens are AES-GCM encrypted with the managed server secret PAYMENT_CONFIG_KEY. That key must be preserved for existing records to remain readable. Item tokens never enter general family-office state or client responses. Session claims are bound to the owner, household and configuration, expire after 30 minutes, and cannot be exchanged twice. Configuration updates use conditional writes. The bank connection history is separate from accounting journals.

Accounts/get supplies account snapshots; balances may be cached. Refreshing the account data is not a real-time settlement-funds guarantee. Disconnect removes the Plaid Item and its stored token, retaining connection history; it does not close the bank account. To change Plaid clients or environment, disconnect the current Items first.

This integration uses only Link token creation, public-token exchange, accounts/get and item/remove. It does not submit transfers, automate bill payment, synchronize the Google ledger or implement LND/USD conversion. Plaid Transfer approval and an independently verified payment and USD-funding arrangement are separate work. No LND conversion rate is treated as externally verified.

Verification: scripts/test-plaid.mjs uses a mocked Plaid API to check encryption, isolation, consent, token replay/expiry, refresh recovery and disconnection. Tests have not linked a real bank or verified live Plaid credentials. Run scripts/build.sh before this test, as it imports the assembled Worker. Browser/Plaid consent testing remains necessary once credentials are entered.
