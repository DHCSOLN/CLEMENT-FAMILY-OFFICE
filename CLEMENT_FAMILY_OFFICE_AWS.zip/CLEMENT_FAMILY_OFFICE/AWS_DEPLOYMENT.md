# Clement Family Office: GitHub source and AWS hosting

This package preserves application source from the published Clement Family Office commit `b504b5f383df8ea23709136f6f6781148ebe8be3` and adds an AWS hosting adapter. The current Sites application is not modified by installation.

## Run in AWS CloudShell

Upload and extract this package. In its directory run:

```
python3 aws/deploy.py
```

The installer checks AWS account `944870884457`, runs the application and adapter tests, asks privately for a GitHub token with contents read/write permission to `DHCSOLN/CLEMENT-FAMILY-OFFICE`, verifies that the repository is private, and commits source under `family-office/` on branch `deployment/aws-family-office`. Existing main-branch content is preserved. It then deploys AWS and prints the verified application and login URLs.

The GitHub token is held in memory, never written to disk or included in the archive. A fine-grained GitHub token can be restricted to this repository and Contents read/write. It is not a Google OAuth token. Do not paste tokens or passwords into chat.

The installer asks for an initial strong password for the existing application owner's email, `dynastyhealing1111@gmail.com`. It is set only when the AWS user is newly created or still requires an initial password. Cognito requires an authenticator-app MFA setup on first sign-in. No invitation email is sent by the installer. Use the generated `/auth/login` link.

Optional independent modes are `--github-only` and `--aws-only`. AWS-only mode does not claim source was pushed to GitHub. The normal command does both and stops if GitHub access fails.

## What AWS creates

- A new `clement-family-office` CloudFormation stack in `us-east-2`, separate from the Visa callback stack.
- A Lambda Node.js 22 backend and HTTPS API Gateway endpoint.
- An admin-provisioned Cognito user pool, with MFA, PKCE authorization-code sign-in and verified signed ID tokens.
- Encrypted, HttpOnly, Secure session cookies. Incoming caller-supplied Sites identity headers are discarded; only verified Cognito identities are passed to the original permission checks.
- A private, encrypted, versioned S3 bucket for family records/documents. Conditional writes preserve concurrent-update protection. A separate private versioned source-code bucket stores Lambda deployment packages.
- A Secrets Manager session key and scoped IAM permissions. No financial records or credentials go into GitHub.

The public root contains only the sign-in screen. Family information is returned only after authentication and the existing application authorization checks. Household separation, professional scopes and independent approval rules are retained. Additional professionals must be provisioned in Cognito and assigned appropriate app scopes; public self-registration is disabled.

## Verification and completion limits

Local tests validate JWT signatures/issuer/audience/expiry/nonce, cookie integrity, PKCE/state checks, identity-header spoof rejection, origin checks, household denial, conditional writes, upload bounds and the original application workflows. They do not prove deployed AWS behavior.

The installer reports AWS success only after the health endpoint responds with the expected application identity and a request for private state without sign-in returns HTTP 401. Complete owner sign-in/MFA and save/reload a nonfinancial record to verify interactive operation. AWS service-side CloudFormation validation occurs in your account during deployment.

Application uploads/downloads on this Lambda/API Gateway adapter are limited to 4 MiB each. Larger documents require a separate authenticated S3 multipart/presigned workflow, which is not included. The original Sites service's 100 MB upload limit must not be assumed to apply on AWS.

**Existing private Sites records, uploaded documents, source archives, access assignments and Plaid secrets are not copied by a source deployment.** They remain on the existing Site. A separate authorized data migration is needed before AWS can be treated as the authoritative family record store. The new AWS storage begins empty, with the existing owner interface's initial seed data on first use. Do not delete the existing Site or its data.

The AWS copy uses Cognito user IDs, so any migrated user-bound grants/approvals require identity mapping. Stored Plaid tokens/configuration require explicit migration or reconnection using the AWS encryption key; copying encrypted values alone is insufficient. Register the AWS origin/redirect with Plaid before reconnecting. No Plaid transfer capability is activated by installation.

This package does not connect Google Apps Script, resolve its multiple doPost handlers, or submit payments. It does not configure Visa, PMI, GFI or FX execution. Its health response explicitly reports `ledgerConnected: false` and `paymentExecution: false`. These are the next integrations after AWS hosting and source publication are verified.

The installer does not change DNS or existing `stateoflocnation.com`, `globalsolnreserve.com` or `visa.globalsolnreserve.com` hosting. It prints a new AWS URL. Custom domain mapping follows verification of the deployed application.

## Source and operations

All app source, agreement templates, build scripts, tests, Google integration examples, the AWS adapter and deployment template are included. Tracked `worker/index.js` is the exact generated source snapshot used by the package; the adapter executes it without trusting external identity headers. No private operational records are included.

GitHub source URL after a successful upload:
`https://github.com/DHCSOLN/CLEMENT-FAMILY-OFFICE/tree/deployment/aws-family-office/family-office`

The AWS account incurs its normal service charges. Data buckets, Cognito users and session key are retained by CloudFormation on stack deletion. Do not delete deployment resources to troubleshoot an update; inspect CloudFormation events and preserve existing data.
